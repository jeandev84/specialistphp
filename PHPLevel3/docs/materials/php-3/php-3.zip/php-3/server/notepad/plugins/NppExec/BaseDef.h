#define WM_COMMAND     0x0111
#define WM_SYSCOMMAND  0x0112
#define WM_USER        0x0400
#define NPPMSG         (WM_USER + 1000)

// add more definitions if needed...
#define pi 3.14159265359
#define e  2.718281828459
