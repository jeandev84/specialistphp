<?php
define("HOST_NAME", "http://" . $_SERVER['HTTP_HOST'] . "/demo/curl/");