<?php

  $db = new PDO("sqlite:users.db");
    
/*
  //INSERT
  $count = $db->exec("INSERT INTO user(name, email) VALUES ('John', 'john@gmail.com')");

  echo $count;
*/
/*
  //UPDATE
  $count = $db->exec("UPDATE user SET email='john@mail.ru' WHERE name='John'");

  echo $count;
*/
