﻿<?php
	setcookie("test", "hello");
?>