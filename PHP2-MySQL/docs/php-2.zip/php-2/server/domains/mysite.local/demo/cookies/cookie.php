<?php
	setcookie("userName", 'John');
?>