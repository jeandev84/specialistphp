<?
header("Content-type: file/octet-stream");
header("Content-disposition: attachment; filename=\"mytext.txt\"");
?>
<!DOCTYPE HTML>
<html>
<head>
	<title>My page</title>
</head>

<body>
<h1>My page</h1>


</body>
</html>
