<?
header("Refresh: 3; url=http://www.specialist.ru");
?>
<!DOCTYPE HTML>

<html>
<head>
	<meta charset="utf-8" />
	<title>Перезапрос страницы</title>
</head>

<body>
<h1>Перезапрос страницы</h1>
Через 3 секунды вы увидите specialist.ru
</body>
</html>
