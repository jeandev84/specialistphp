<?
header("Content-type: text/html; charset=utf-8");
?>
<!DOCTYPE HTML>

<html>
<head>
	<title>Что-то по русски</title>
	<!--meta http-equiv='Content-Type' content='text/html;charset=windows-1251'/-->
</head>

<body>
<h1>Что-то по русски</h1>
</body>
</html>
